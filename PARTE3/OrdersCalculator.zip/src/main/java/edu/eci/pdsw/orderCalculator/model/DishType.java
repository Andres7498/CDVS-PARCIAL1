package edu.eci.pdsw.orderCalculator.model;

public enum DishType {
    DRINK, PLATE
}