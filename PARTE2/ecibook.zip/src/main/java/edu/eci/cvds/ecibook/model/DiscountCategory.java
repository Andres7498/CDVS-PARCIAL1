package edu.eci.cvds.ecibook.model;

/**
 * The available subscription categories.
 */
public enum DiscountCategory {

	EMPLOYEE,
	STUDENT,
	OTHER;
}
